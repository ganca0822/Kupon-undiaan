<?php
$telegram_id = "7725881819";
$id_bot      = "8116136908:AAGDYa_gZS0CQk90kb8CcnPZxDXtduEO5A8";
?>